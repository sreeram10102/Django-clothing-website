from django import forms

class AuthForm(forms.Form):
    username = forms.CharField()
    password = forms.CharField()
    def clean(self):
     cleaned_data = super().clean()
    pass