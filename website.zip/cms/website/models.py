from django.db import models
import datetime
from django.conf import settings

class Profile_check(models.Model):
     user = models.OneToOneField(settings.AUTH_USER_MODEL,
                                 related_name ='profile_of_Users',
                                 on_delete = models.CASCADE )
     date_of_birth = models.DateTimeField(blank=False)
     Student_id = models.CharField(max_length=10)
     image = models.ImageField(upload_to= 'images/%Y/%m/%d/')
     sem_start = models.ImageField(blank=False)

class Bachelor_Courses(models.Model):      #the relation here is that one user can take only one course ...but that course can be take by multiple users
     user = models.ForeignKey(settings.AUTH_USER_MODEL,
                                 related_name ='courses_taken',
                                  on_delete = models.CASCADE)
     course_name = models.CharField(max_length=20)
     Proffesor = models.CharField(max_length=20)

class Sports(models.Model):
     user1 = models.ManyToManyField(settings.AUTH_USER_MODEL)
     sport_name = models.CharField(max_length=20)
     course_location = models.CharField(max_length=20)
