

from django.conf import settings
from django.shortcuts import redirect, render
from django.http import HttpResponse
from .forms import AuthForm
from django.contrib.auth import authenticate,login
from django.views.generic.edit import FormView
from website.models import Profile_check,Bachelor_Courses
from django.contrib.auth.decorators import login_required

def start(request):
    return HttpResponse("Hello , mein lieber")

class loginFormView(FormView):
    template_name = "login.html"
    form_class = AuthForm
    success_url = "/dashboard/"

    def form_valid(self,form):
    
     
     
    
     username = form.cleaned_data.get('username')
     password = form.cleaned_data.get('password')
     user = authenticate(username=username,password=password)
     
     if user is not None:
     
      return redirect("/dashboard/") #super().form_valid(form)
     else:
      return redirect("/login/")

         


    

@login_required
def dashboard(request):
 
 
 return_my_profile = request.user.courses_taken
 
 #return render(request,'dashboard.html',{'return':return_my_profile})
 return HttpResponse(request.user)  
     









def logout(request):
 form = AuthForm(request.POST)
 return render(request,'logout.html',{"form":form})

 