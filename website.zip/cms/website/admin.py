from django.contrib import admin
from .models import Sports,Bachelor_Courses,Profile_check


@admin.register(Sports,Bachelor_Courses,Profile_check)
class Sportsadmin(admin.ModelAdmin):
    pass
class Bachelor_Coursesadmin(admin.ModelAdmin):
    pass
class Profile_checkadmin(admin.ModelAdmin):
    pass


# Register your models here.
